import MyForm from './components/forms/form';

function App() {
  return (
    <>
      <MyForm />
    </>
  );
}

export default App;
